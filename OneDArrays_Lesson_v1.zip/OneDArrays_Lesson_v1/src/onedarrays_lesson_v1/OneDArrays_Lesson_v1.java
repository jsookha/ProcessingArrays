/*
Program: 	James Bond Data / Sample Lesson 
Programmer: 	J.Sookha 
Date:           26 August 2021
Description: 	Processing and evaluating data that is stored in parallel 
                1-dimensional arrays. 

                We will be using data based on the James Bond movies after its 
                50 year anniversary. 
*/
package onedarrays_lesson_v1;

import javax.swing.JOptionPane;
import java.text.DecimalFormat;

public class OneDArrays_Lesson_v1 {
    
    //static int[] intYear = {1962,1963,1964,1965,1967,1969,1971,1973,1974,1977,1979,1981,1983,1985,1987,1989,1995,1997,1999,2002,2006,2008};

    
    static int[] intYear = new int[22]; // year movie was released
    static String[] strMovieTitle = new String[22]; // name of the movies
    
    static String[] strActor = new String[22]; // Actor surnam
    
    static int[] intKills = new int[22]; // number of kills in the movie
    static int[] intGirlsKissed = new int[22];
    static int[] intSleptWith = new int[22];
    static int[] intEnemy = new int[22]; // enemies who believed that Bond was dead
    
    static double[] dblBoxUS = new double[22]; // Box Office US Only $
    static double[] dblBoxOverSeas = new double[22]; // Overseas Box Office only $			
    static double[] dblBudget = new double[22]; // Movie budget $

    static int intCounter; 
    static DecimalFormat df2 = new DecimalFormat("#.##");
     
    public static void main(String[] args) {
        loadData(); // loading all 10 arrays with their respective data
        displayData();
        
        SequentialSearch();
        
        // avgBoxOffice();
        
        // highlowBoxOffice();
        
        
    }
    
    public static double totalBoxOffice(int intIndex)
    {
        double dblTotalBoxAmt = 0; 
        dblTotalBoxAmt = dblBoxUS[intIndex] + dblBoxOverSeas[intIndex]; 
        return dblTotalBoxAmt; 
        
        // return dblBoxUS[intIndex] + dblBoxOverSeas[intIndex];
    }
    
    public static double profitability(int intIndex)
    {
        double dblProfit = 0; 
        dblProfit = totalBoxOffice(intIndex) / dblBudget[intIndex];
        //dblProfit = (totalBoxOffice(intIndex) / dblBudget[intIndex])*100;
        
        return dblProfit; 
    }
    
    public static void loadData()
    {
        intYear[0]  =  1962;
        intYear[1] = 1963;
        intYear[2] = 1964;
        intYear[3] = 1965;
        intYear[4] = 1967;
        intYear[5] = 1969;
        intYear[6] = 1971;
        intYear[7] = 1973;
        intYear[8] = 1974;
        intYear[9] = 1977;
        intYear[10] = 1979;
        intYear[11] = 1981;
        intYear[12] = 1983;
        intYear[13] = 1985;
        intYear[14] = 1987;
        intYear[15] = 1989;
        intYear[16] = 1995;
        intYear[17] = 1997;
        intYear[18] = 1999;
        intYear[19] = 2002;
        intYear[20] = 2006;
        intYear[21] = 2008;

        strMovieTitle[0] = "Dr. No";
        strMovieTitle[1] = "From Russia With Love";
        strMovieTitle[2] = "Goldfinger";
        strMovieTitle[3] = "Thunderball";
        strMovieTitle[4] = "You Only Live Twice";
        strMovieTitle[5] = "On Her Majesty's Secret Service";
        strMovieTitle[6] = "Diamonds Are Forever";
        strMovieTitle[7] = "Live and Let Die";
        strMovieTitle[8] = "The Man with the Golden Gun";
        strMovieTitle[9] = "The Spy Who Loved Me";
        strMovieTitle[10] = "Moonraker";
        strMovieTitle[11] = "For Your Eyes Only";
        strMovieTitle[12] = "Octopussy";
        strMovieTitle[13] = "A View to Kill";
        strMovieTitle[14] = "The Living Daylights";
        strMovieTitle[15] = "Licence to Kill";
        strMovieTitle[16] = "Goldeneye";
        strMovieTitle[17] = "Tomorrow Never Dies";
        strMovieTitle[18] = "The World is Not Enough";
        strMovieTitle[19] = "Die Another Day";
        strMovieTitle[20] = "Casino Royale";
        strMovieTitle[21] = "Quantum of Solace";
        
        strActor[0] = "Connery";
        strActor[1] = "Connery";
        strActor[2] = "Connery";
        strActor[3] = "Connery";
        strActor[4] = "Connery";
        strActor[5] = "Lazenby";
        strActor[6] = "Connery";
        strActor[7] = "Moore";
        strActor[8] = "Moore";
        strActor[9] = "Moore";
        strActor[10] = "Moore";
        strActor[11] = "Moore";
        strActor[12] = "Moore";
        strActor[13] = "Moore";
        strActor[14] = "Dalton";
        strActor[15] = "Dalton";
        strActor[16] = "Brosnan";
        strActor[17] = "Brosnan";
        strActor[18] = "Brosnan";
        strActor[19] = "Brosnan";
        strActor[20] = "Craig";
        strActor[21] = "Craig";

        intKills[0] = 5;
        intKills[1] = 6;
        intKills[2] = 3;
        intKills[3] = 14;
        intKills[4] = 17;
        intKills[5] = 6;
        intKills[6] = 6;
        intKills[7] = 4;
        intKills[8] = 1;
        intKills[9] = 11;
        intKills[10] = 12;
        intKills[11] = 8;
        intKills[12] = 12;
        intKills[13] = 3;
        intKills[14] = 4;
        intKills[15] = 7;
        intKills[16] = 26;
        intKills[17] = 17;
        intKills[18] = 17;
        intKills[19] = 16;
        intKills[20] = 10;
        intKills[21] = 15;

        intGirlsKissed[0] = 4;
        intGirlsKissed[1] = 2;
        intGirlsKissed[2] = 4;
        intGirlsKissed[3] = 3;
        intGirlsKissed[4] = 4;
        intGirlsKissed[5] = 3;
        intGirlsKissed[6] = 1;
        intGirlsKissed[7] = 2;
        intGirlsKissed[8] = 3;
        intGirlsKissed[9] = 3;
        intGirlsKissed[10] = 3;
        intGirlsKissed[11] = 3;
        intGirlsKissed[12] = 2;
        intGirlsKissed[13] = 4;
        intGirlsKissed[14] = 1;
        intGirlsKissed[15] = 3;
        intGirlsKissed[16] = 3;
        intGirlsKissed[17] = 3;
        intGirlsKissed[18] = 3;
        intGirlsKissed[19] = 3;
        intGirlsKissed[20] = 2;
        intGirlsKissed[21] = 2;

        intSleptWith[0] = 3;
        intSleptWith[1] = 4;
        intSleptWith[2] = 2;
        intSleptWith[3] = 3;
        intSleptWith[4] = 2;
        intSleptWith[5] = 3;
        intSleptWith[6] = 1;
        intSleptWith[7] = 3;
        intSleptWith[8] = 2;
        intSleptWith[9] = 2;
        intSleptWith[10] = 3;
        intSleptWith[11] = 2;
        intSleptWith[12] = 2;
        intSleptWith[13] = 4;
        intSleptWith[14] = 2;
        intSleptWith[15] = 2;
        intSleptWith[16] = 2;
        intSleptWith[17] = 2;
        intSleptWith[18] = 3;
        intSleptWith[19] = 2;
        intSleptWith[20] = 1;
        intSleptWith[21] = 1;

        intEnemy[0] = 1;
        intEnemy[1] = 0;
        intEnemy[2] = 0;
        intEnemy[3] = 0;
        intEnemy[4] = 1;
        intEnemy[5] = 1;
        intEnemy[6] = 2;
        intEnemy[7] = 0;
        intEnemy[8] = 0;
        intEnemy[9] = 0;
        intEnemy[10] = 0;
        intEnemy[11] = 1;
        intEnemy[12] = 1;
        intEnemy[13] = 3;
        intEnemy[14] = 0;
        intEnemy[15] = 0;
        intEnemy[16] = 0;
        intEnemy[17] = 1;
        intEnemy[18] = 1;
        intEnemy[19] = 1;
        intEnemy[20] = 1;
        intEnemy[21] = 0;

        dblBoxUS[0] = 16067053;
        dblBoxUS[1] = 24796765;
        dblBoxUS[2] = 51081062;
        dblBoxUS[3] = 63595658;
        dblBoxUS[4] = 43084787;
        dblBoxUS[5] = 22774493;
        dblBoxUS[6] = 43819547;
        dblBoxUS[7] = 35377836;
        dblBoxUS[8] = 20972000;
        dblBoxUS[9] = 46838673;
        dblBoxUS[10] = 70308099;
        dblBoxUS[11] = 54812802;
        dblBoxUS[12] = 67893619;
        dblBoxUS[13] = 50327960;
        dblBoxUS[14] = 51185897;
        dblBoxUS[15] = 34667015;
        dblBoxUS[16] = 106429941;
        dblBoxUS[17] = 125304276;
        dblBoxUS[18] = 126943684;
        dblBoxUS[19] = 160942139;
        dblBoxUS[20] = 167445960;
        dblBoxUS[21] = 168368427;

        dblBoxOverSeas[0] = 43500000;
        dblBoxOverSeas[1] = 54100000;
        dblBoxOverSeas[2] = 73800000;
        dblBoxOverSeas[3] = 77600000;
        dblBoxOverSeas[4] = 68500000;
        dblBoxOverSeas[5] = 59200000;
        dblBoxOverSeas[6] = 72200000;
        dblBoxOverSeas[7] = 126400000;
        dblBoxOverSeas[8] = 76600000;
        dblBoxOverSeas[9] = 138600000;
        dblBoxOverSeas[10] = 140000000;
        dblBoxOverSeas[11] = 140500000;
        dblBoxOverSeas[12] = 119600000;
        dblBoxOverSeas[13] = 102300000;
        dblBoxOverSeas[14] = 140015000;
        dblBoxOverSeas[15] = 121500000;
        dblBoxOverSeas[16] = 245764093;
        dblBoxOverSeas[17] = 207706792;
        dblBoxOverSeas[18] = 234888716;
        dblBoxOverSeas[19] = 271028977;
        dblBoxOverSeas[20] = 426793106;
        dblBoxOverSeas[21] = 417722300;

        dblBudget[0] = 1100000;
        dblBudget[1] = 2000000;
        dblBudget[2] = 3000000;
        dblBudget[3] = 9000000;
        dblBudget[4] = 9500000;
        dblBudget[5] = 8000000;
        dblBudget[6] = 7200000;
        dblBudget[7] = 7000000;
        dblBudget[8] = 7000000;
        dblBudget[9] = 14000000;
        dblBudget[10] = 31000000;
        dblBudget[11] = 28000000;
        dblBudget[12] = 27500000;
        dblBudget[13] = 30000000;
        dblBudget[14] = 40000000;
        dblBudget[15] = 42000000;
        dblBudget[16] = 60000000;
        dblBudget[17] = 110000000;
        dblBudget[18] = 135000000;
        dblBudget[19] = 142000000;
        dblBudget[20] = 102000000;
        dblBudget[21] = 230000000;

    }
    
    public static void displayData()
    {
        String strDisplay, strFormatted; 
        strDisplay = "";
        
        strFormatted = "|%-50s (%-4d) | Kills %2d | Girls Kissed %2d | Slept With %2d | Enemies %2d \n";
        
        for (intCounter= 0; intCounter <= 21; intCounter++)
        {
            strDisplay = strDisplay + String.format(strFormatted, strMovieTitle[intCounter], intYear[intCounter],intKills[intCounter],intGirlsKissed[intCounter],intSleptWith[intCounter],intEnemy[intCounter]);
        }
     
        JOptionPane.showMessageDialog(null,strDisplay);
    }
    
    public static void avgBoxOffice()
    {
        double dblSumUS, dblAvgUS, dblSumOver, dblAvgOver; 
        
        dblSumUS = 0; 
        dblSumOver = 0;
        
        for (intCounter = 0; intCounter <= 21; intCounter++)
        {
            dblSumUS = dblSumUS + dblBoxUS[intCounter];
            dblSumOver = dblSumOver + dblBoxOverSeas[intCounter]; 
        }
        
        dblAvgUS = dblSumUS / 22;
        dblAvgOver = dblSumOver / 22;
        
        JOptionPane.showMessageDialog(null,"Average US Box Office - " + df2.format(dblAvgUS) + "\n" + 
                                           "Average Overseas Box Office - " + df2.format(dblAvgOver));
    }
    
    public static void highlowBoxOffice()
    {
        int intSavedHighIndex, intSavedLowIndex;
        double dblHighBox, dblLowBox; 
        
        intSavedHighIndex = 0; // have to do this
        intSavedLowIndex = 0;  
        
        dblHighBox = -1; 
        dblLowBox = 999999999;
        
         for (intCounter = 0; intCounter <= 21; intCounter++)
        {
            if (totalBoxOffice(intCounter) < dblHighBox)
            {
                dblHighBox = totalBoxOffice(intCounter);
                intSavedHighIndex = intCounter;
            }
            
            if (totalBoxOffice(intCounter) < dblLowBox)
            {
                dblLowBox = totalBoxOffice(intCounter);
                intSavedLowIndex = intCounter;
            }
        }
         
         JOptionPane.showMessageDialog(null,"Highest Box Office - " + df2.format(dblHighBox) + " for  " + strMovieTitle[intSavedHighIndex] + "\n" + 
                                            "Lowest  Box Office - " + df2.format(dblLowBox) + " for  " + strMovieTitle[intSavedLowIndex]);
        
    }
    
    public static void SequentialSearch()
    {
        String strSearch, strDisplay, strFormatted; 
        int intFlag, intFoundIndex; 
        
        
        strDisplay = "";
        strFormatted = "%-60s (%-4d) \n";
        strSearch = ""; 
        
        strSearch = JOptionPane.showInputDialog("Please enter the actor's surname ");
        intFlag = -1; // not found yet
        intFoundIndex = -1;
        
        for (intCounter = 0; intCounter <= 21; intCounter++)
        {
            if (strSearch.equals(strActor[intCounter]))
            {
                intFlag = 1; // actor found 
                intFoundIndex = intCounter;
                strDisplay = strDisplay + String.format(strFormatted, strMovieTitle[intCounter], intYear[intCounter]);
            }
        }
        
        if (intFlag == -1) // testing that it was never found
        {
            JOptionPane.showMessageDialog(null,"Actor not found","Search Error",JOptionPane.ERROR_MESSAGE);
        }
        else 
        {
            //found the actor
            JOptionPane.showMessageDialog(null,strDisplay,"Search Actor Found - "+strActor[intFoundIndex],JOptionPane.PLAIN_MESSAGE);
        }
    }
}
